<?php

namespace App\Filters;

class UserFilter extends Filter
{
}
